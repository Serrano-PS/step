#ifndef _TESTE_BUS_
#define _TESTE_BUS_

#include "bus.h"

/*
Calcular:
1 - a media salarial
2 - a media de idade
3 - qtas pessoas entre 15 e 20 anos; entre 21 e 25; entre 26 e 30; 31 e 35; 36 e 40; e acima de 41

*/

void teste_bus();
#endif