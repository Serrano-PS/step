#ifndef _TESTE_PER_
#define _TESTE_PER_

#include "per.h"

/*
Saida: arquivo 'estatisticas.txt':
media - salarial; media - idade; idade1,idade2,qdte ; idade1,idade2,qdte ; idade1,idade2,qdte\n
*/

void teste_per();

void teste_per_in();

void teste_per_out();

#endif

